import json
import requests

url="https://api.data.gov.sg/v1/environment/2-hour-weather-forecast"
req=requests.get(url)

data = json.loads(req.text)

forecasts = data["items"][0]["forecasts"]

# print the first item's area 
print(forecasts[0]["area"]) # Ang Mo Kio

# print the first item's forcast
print(forecasts[0]["forecast"]) # Partly Cloudy (Day) <- this is just a snapshot

# printing all values
print("----------------- All Area and Weather Forecast ------------------")
for forecast in forecasts:
    area = forecast["area"]
    weather = forecast["forecast"]
    print(area + ": " + weather)
    