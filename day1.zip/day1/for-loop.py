numbers = range(10)

for i in numbers:
    print(i)
    
s = "freedom"
for c in s:
    print(c, end= " ")